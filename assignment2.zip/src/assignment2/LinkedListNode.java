package assignment2;

/**
 * Implementation of linked list
 *   
 * @author Igor
 *
 */


public class LinkedListNode<T> {

	private T data;
	private LinkedListNode<T> next;

	public LinkedListNode(T data) {
		this.data = data;
		this.next = null;
	}

	public LinkedListNode(T data, LinkedListNode<T> next) {
		this.data = data;
		this.next = next;
	}
	
	public T getData() {
		return data;
	}
	
	public LinkedListNode<T> getNext() {
		return next;
	}
	
	public void setData(T data) {
		this.data = data;
	}
	
	public void setNext(LinkedListNode<T> next) {
		this.next = next;
	}


	public LinkedListNode<T> head(LinkedListNode<T> head){

		if (head == null || head.next == null)
			return null;

		LinkedListNode<T> slow = head, fast = head;


		while (fast != null && fast.next != null)
		{

			slow = slow.next;
			fast = fast.next.next;
			if (slow == fast)
				break;
		}

		if (slow != fast)
			return null;

		slow = head;

		while (slow != fast)
		{
			slow = slow.next;
			fast = fast.next;
		}
		return slow;
	}

	public int countReachableNodes( ) {
		int length = 1;
		if (this == null)
			return 0;

		LinkedListNode<T> head = this;
		LinkedListNode<T> start = head(this);
		if (start == null){
			while (head.getNext() != null) {
				length++;
				head = head.next;
			}
		}else{
			if(head == start){
				while(head.getNext() != start){
					length++;
					head = head.next;
				}
			}
			else {
				while (head.getNext() != start) {
					length++;
					head = head.next;
				}
				head = head.next;
				length++;
				while (head.getNext() != start) {
					length++;
					head = head.next;
				}
			}
		}
		// TODO implement me
		return length;
	}



	}
