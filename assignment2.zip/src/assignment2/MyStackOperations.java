package assignment2;

import mystack.MyStack;

/**
 * Additional operations on MyStack
 * 
 * @author Igor
 *
 */

public class MyStackOperations<T> {

	public static <T> int size(MyStack<T> s) {
		MyStack<T> clone = new MyStack<T>();
		T temp;
		int size = 0;
		while(!s.isEmpty()) {
			temp = s.pop();
			clone.push(temp);
			size++;
		}
		while(!clone.isEmpty()) {
			temp = clone.pop();
			s.push(temp);
		}
		return size;
	}

	public static <T> MyStack<T> cloneStack(MyStack<T> s) {
		// TODO implement me
		MyStack<T> clone = new MyStack<T>();
		T temp;
		MyStack<T> clone2 = new MyStack<T>();

		while(!s.isEmpty()){
			temp = s.pop();
			clone.push(temp);
		}
		while(!clone.isEmpty()){
			temp = clone.pop();
			clone2.push(temp);
			s.push(temp);
		}
		return clone2;
	}

	public static <T> void reverse(MyStack<T> s) {

		MyStack<T> temp= new MyStack<T>();

		MyStack<T> temp2= new MyStack<T>();

		if(s.isEmpty())
			return;

		while(!s.isEmpty()){
			temp.push(s.pop());
		}
		while(!temp.isEmpty()){
			temp2.push(temp.pop());
		}
		while(!temp2.isEmpty()){
			s.push(temp2.pop());
		}
	}
}


	